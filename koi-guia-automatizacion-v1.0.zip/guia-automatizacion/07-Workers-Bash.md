# 📘 Capítulo 7 — Workers Bash para Automatización

## Template base mejorado

```bash
#!/bin/bash
# Nombre.sh - Descripción
set -euo pipefail

# === CONFIG ===
NAME="mi-worker"
LOG="$HOME/.openwork/logs/${NAME}.log"
LOCK="/tmp/${NAME}.lock"
MAX_LOG=10000
ERR_COUNT=0
MAX_ERRS=5  # Auto-desactivar tras N errores consecutivos

# === HELPERS ===
log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG"; }
die() { log "❌ FATAL: $*"; rm -f "$LOCK"; exit 1; }

# === LOCK (evitar duplicados) ===
if [ -f "$LOCK" ]; then
  LOCK_AGE=$(( $(date +%s) - $(stat -c %Y "$LOCK") ))
  if [ "$LOCK_AGE" -lt 3600 ]; then
    exit 0  # Otro worker corriendo
  else
    log "⚠️ Lock viejo (${LOCK_AGE}s), removiendo..."
    rm -f "$LOCK"
  fi
fi
touch "$LOCK"
trap 'rm -f "$LOCK"' EXIT

# === LOG ROTATION ===
rotate() {
  local lines=$(wc -l < "$LOG" 2>/dev/null || echo 0)
  if [ "$lines" -gt "$MAX_LOG" ]; then
    tail -n $((MAX_LOG / 2)) "$LOG" > "${LOG}.tmp"
    mv "${LOG}.tmp" "$LOG"
  fi
}

log "🚀 Iniciando $NAME"

# === TU LÓGICA AQUÍ ===

log "✅ $NAME completado"
rotate
```

---

## Worker: Monitor de precios (productos Gumroad)

```bash
#!/bin/bash
# monitor-prices.sh - Compara precios de competidores
set -euo pipefail

LOG="$HOME/.openwork/logs/monitor-prices.log"
STATE="$HOME/.openwork/state/last-prices.json"
mkdir -p "$HOME/.openwork/state"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG"; }

# Lista de productos a monitorear (URL + selector)
PRODUCTS=(
  "competidor-a.com|producto-1|29"
  "competidor-b.com|producto-2|49"
)

CHANGES=0
for entry in "${PRODUCTS[@]}"; do
  IFS='|' read -r domain product current_price <<< "$entry"
  NEW_PRICE=$(curl -s "https://$domain/products/$product" | \
    grep -oP '\$\K[0-9]+' | head -1)
  
  if [ -n "$NEW_PRICE" ] && [ "$NEW_PRICE" != "$current_price" ]; then
    log "💰 Cambio detectado: $product - $current_price → $NEW_PRICE"
    CHANGES=$((CHANGES + 1))
  fi
done

if [ "$CHANGES" -gt 0 ]; then
  log "📊 $CHANGES cambios de precio detectados"
fi
```

---

## Worker: Backup automático

```bash
#!/bin/bash
# auto-backup.sh
set -euo pipefail

BACKUP_DIR="$HOME/.openwork/backups"
TODAY=$(date +%Y-%m-%d)
SOURCE_DIRS=(
  "$HOME/.openwork"
  "$HOME/.openclaw/workspace"
)
RETENTION_DAYS=30
LOG="$HOME/.openwork/logs/backup.log"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG"; }

mkdir -p "$BACKUP_DIR"

BACKUP_FILE="$BACKUP_DIR/backup-$TODAY.tar.gz"
tar -czf "$BACKUP_FILE" \
  --exclude='*.log' \
  --exclude='node_modules' \
  --exclude='backups' \
  "${SOURCE_DIRS[@]}" 2>/dev/null

SIZE=$(du -sh "$BACKUP_FILE" | cut -f1)
log "💾 Backup creado: $BACKUP_FILE ($SIZE)"

# Limpiar backups antiguos
find "$BACKUP_DIR" -name "backup-*.tar.gz" -mtime +$RETENTION_DAYS -delete
log "🧹 Backups antiguos (>$RETENTION_DAYS días) eliminados"
```

---

## Worker: Health check de servicios

```bash
#!/bin/bash
# health-check.sh - Monitorea servicios y envía alertas
set -euo pipefail

CREDS="$HOME/.openwork/credentials.json"
TG_TOKEN=$(jq -r '.telegram_bot_token' "$CREDS")
TG_CHAT=$(jq -r '.telegram_chat_id' "$CREDS")
LOG="$HOME/.openwork/logs/health.log"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG"; }
alert() {
  curl -s "https://api.telegram.org/bot$TG_TOKEN/sendMessage" \
    -d "chat_id=$TG_CHAT" \
    -d "text=🚨 $1" > /dev/null
}

check_service() {
  local name="$1"
  local url="$2"
  
  STATUS=$(curl -so /dev/null -w '%{http_code}' "$url" 2>/dev/null || echo "000")
  
  if [ "$STATUS" -ge 200 ] && [ "$STATUS" -lt 400 ]; then
    log "✅ $name: HTTP $STATUS"
  else
    log "❌ $name: HTTP $STATUS"
    alert "$name caído! (HTTP $STATUS)"
  fi
}

check_disk() {
  USAGE=$(df / | awk 'NR==2 {print $5}' | tr -d '%')
  if [ "$USAGE" -gt 85 ]; then
    log "⚠️ Disco: $USAGE% usado"
    alert "Disco al $USAGE% en $(hostname)"
  fi
}

check_service "n8n" "http://localhost:5678/healthz"
check_service "webhook" "http://localhost:5679/health"
check_disk
```

---

## Cómo combinar varios workers

```crontab
# Cada hora: health check
0 * * * * bash ~/.openwork/workers/health-check.sh

# Cada 6h: backup
0 */6 * * * bash ~/.openwork/workers/auto-backup.sh

# Diario 8am: resumen
0 8 * * * ~/.openwork/workers/daily-reminder.sh

# Lun-Vie 9am: monitoreo
0 9 * * 1-5 ~/.openwork/workers/monitor-prices.sh
```

---

## Próximo capítulo

→ **[08-Tracking-Ingresos.md](08-Tracking-Ingresos.md)** — Sistema de tracking financiero.
