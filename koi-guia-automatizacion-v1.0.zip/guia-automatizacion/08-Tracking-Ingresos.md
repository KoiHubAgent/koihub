# 📘 Capítulo 8 — Sistema de Tracking Financiero

## El problema

Sin tracking financiero, no sabes:
- Cuánto ingresas por fuente
- Cuánto te cuesta cada herramienta
- Qué productos venden y cuáles no
- Cuánto pagarás de impuestos

---

## La solución: SQLite + scripts

### Inicializar la base de datos

```bash
DB="$HOME/.openwork/finance.db"

sqlite3 "$DB" << 'SQL'
CREATE TABLE IF NOT EXISTS ingresos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  fecha TEXT NOT NULL DEFAULT (date('now')),
  fuente TEXT NOT NULL,
  producto TEXT,
  monto REAL NOT NULL,
  moneda TEXT DEFAULT 'USD',
  plataforma TEXT,
  cliente TEXT,
  notas TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS gastos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  fecha TEXT NOT NULL DEFAULT (date('now')),
  categoria TEXT NOT NULL,
  descripcion TEXT,
  monto REAL NOT NULL,
  moneda TEXT DEFAULT 'EUR',
  herramienta TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE VIEW IF NOT EXISTS balance_mensual AS
SELECT
  strftime('%Y-%m', fecha) AS mes,
  SUM(CASE WHEN monto > 0 THEN monto ELSE 0 END) AS ingresos,
  SUM(CASE WHEN monto < 0 THEN monto ELSE 0 END) AS gastos,
  SUM(monto) AS balance
FROM (
  SELECT fecha, monto FROM ingresos
  UNION ALL
  SELECT fecha, -monto FROM gastos
)
GROUP BY mes
ORDER BY mes DESC;
SQL

echo "✅ DB de finances inicializada: $DB"
```

---

## Script: Registrar ingreso/gasto

```bash
#!/bin/bash
# koi-finance.sh — Sistema financiero

DB="$HOME/.openwork/finance.db"

registro_ingreso() {
  local fuente="$1" monto="$2" producto="${3:-}" moneda="${4:-USD}"
  sqlite3 "$DB" "INSERT INTO ingresos (fuente, monto, producto, moneda) \
    VALUES ('$fuente', $monto, '$producto', '$moneda');"
  echo "💰 Ingreso registrado: $fuente +$monto $moneda"
}

registro_gasto() {
  local categoria="$1" monto="$2" desc="${3:-}" moneda="${4:-EUR}"
  sqlite3 "$DB" "INSERT INTO gastos (categoria, monto, descripcion, moneda) \
    VALUES ('$categoria', $monto, '$desc', '$moneda');"
  echo "💸 Gasto registrado: $categoria -$monto $moneda"
}

show_balance() {
  echo "=== BALANCE ACTUAL ==="
  sqlite3 -header -column "$DB" "
    SELECT fuente, 
           ROUND(SUM(monto), 2) as total,
           moneda
    FROM ingresos 
    GROUP BY fuente, moneda
    ORDER BY total DESC;
  "
  echo ""
  echo "=== GASTOS POR CATEGORÍA ==="
  sqlite3 -header -column "$DB" "
    SELECT categoria,
           ROUND(SUM(monto), 2) as total,
           moneda
    FROM gastos
    GROUP BY categoria, moneda
    ORDER BY total DESC;
  "
  echo ""
  echo "=== BALANCE NETO ==="
  sqlite3 -header -column "$DB" "
    SELECT strftime('%Y-%m', fecha) as mes,
           ROUND(SUM(CASE WHEN monto > 0 THEN monto ELSE 0 END), 2) as ingresos,
           ROUND(SUM(CASE WHEN monto < 0 THEN ABS(monto) ELSE 0 END), 2) as gastos,
           ROUND(SUM(monto), 2) as balance
    FROM (
      SELECT fecha, monto FROM ingresos
      UNION ALL
      SELECT fecha, -ABS(monto) FROM gastos
    )
    GROUP BY mes ORDER BY mes DESC
    LIMIT 6;
  "
}

show_metas() {
  META=${1:-3000}
  ACTUAL=$(sqlite3 "$DB" "SELECT ROUND(SUM(monto), 2) FROM ingresos;" 2>/dev/null || echo "0")
  PORCENTAJE=$(echo "scale=1; $ACTUAL * 100 / $META" | bc 2>/dev/null || echo "0")
  RESTANTE=$(echo "scale=2; $META - $ACTUAL" | bc 2>/dev/null || echo "$META")
  echo "🎯 Meta: $META | Actual: $ACTUAL | Progreso: ${PORCENTAJE}% | Restante: $RESTANTE"
}

case "${1:-help}" in
  ingreso) registro_ingreso "$2" "$3" "$4" "$5" ;;
  gasto) registro_gasto "$2" "$3" "$4" "$5" ;;
  balance) show_balance ;;
  meta) show_metas "$2" ;;
  *) echo "Uso: $0 [ingreso|gasto|balance|meta]" ;;
esac
```

---

## Dashboard financiero (simple)

```bash
# Ver dashboard completo
bash ~/.openwork/koi-finance.sh balance

# Output:
# fuente        total   moneda
# Gumroad       147.0   USD
# Fiverr        0       USD
#
# categoria     total   moneda
# hosting       5.0     EUR
# suscripciones 12.0    EUR
#
# mes       ingresos  gastos  balance
# 2026-05   147.00    17.0    130.00

# Ver progreso hacia meta
bash ~/.openwork/koi-finance.sh meta 3000
# 🎯 Meta: 3000 | Actual: 130.00 | Progreso: 4.3% | Restante: 2870.00
```

---

## Próximo capítulo

→ **[09-Escalar.md](09-Escalar.md)** — De MVP a sistema productivo.
