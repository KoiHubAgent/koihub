# 📘 Capítulo 5 — Publicación Automática en Redes Sociales

## El problema

Publicar manualmente consume 30 min/día. Multiplica por plataformas = horas perdidas.

## La solución

Una vez por semana: escribe todo el contenido en batch (1-2 horas).
El sistema lo publica automáticamente en todas las plataformas.

---

## Arquitectura

```
Contenido semanal (Markdown)
    ↓
Worker: Publica según calendario
    ↓
Twitter/X → Mastodon → LinkedIn → (otros)
    ↓
Log de publicación + tracking
```

---

## El calendario (koi-content-calendar.md)

```markdown
### Lunes
- 09:00 → Twitter: Tip/productividad
- 17:00 → Dev.to: Artículo largo (semanal)

### Miércoles
- 09:00 → Twitter: Thread educativo
- 18:00 → LinkedIn: Caso de estudio

### Viernes
- 09:00 → Twitter: Reflexión semanal
- 17:00 → Newsletter (compila semana)
```

---

## Script de publicación

```bash
#!/bin/bash
# publish-scheduled.sh
# Lee el contenido pendiente y programa publicaciones

set -euo pipefail

TODAY=$(date +%A)
NOW_H=$(date +%H)
CONTENT_FILE="$HOME/.openwork/content-queue/$TODAY.md"
LOG="$HOME/.openwork/logs/social-publish.log"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG"; }

publish_twitter() {
  local text="$1"
  # Usa agent-browser o cookies exportadas
  log "🐦 Twitter: $text"
}

publish_mastodon() {
  local text="$1"
  local token=$(jq -r '.mastodon_token' "$HOME/.openwork/credentials.json")
  local instance="mastodon.social"
  
  curl -s "https://$instance/api/v1/statuses" \
    -H "Authorization: Bearer $token" \
    -d "status=$text&visibility=public"
  log "🐘 Mastodon: publicado"
}

# Leer contenido de hoy y publicar
if [ -f "$CONTENT_FILE" ]; then
  # Parse simple: líneas que empiezan con "- HH:MM → plataforma: contenido"
  while IFS= read -r line; do
    if [[ "$line" =~ ^-\ ([0-9]{2}:[0-9]{2})\ →\ (.+):\ (.+)$ ]]; then
      sched_time="${BASH_REMATCH[1]}"
      platform="${BASH_REMATCH[2]}"
      content="${BASH_REMATCH[3]}"
      
      # Solo publicar si la hora ya pasó
      sched_h="${sched_time%%:*}"
      if [ "$sched_h" -le "$NOW_H" ]; then
        case "$platform" in
          twitter|Tweet) publish_twitter "$content" ;;
          mastodon) publish_mastodon "$content" ;;
          *) log "⚠️ Plataforma desconocida: $platform" ;;
        esac
      fi
    fi
  done < "$CONTENT_FILE"
else
  log "📭 Sin contenido programado para hoy"
fi
```

---

## Reglas de oro (lección de Mastodon suspendida)

```
80% valor real
20% soft mention (solo si encaja orgánicamente)

NUNCA:
- Hashtags comerciales
- Posts que suenen a anuncio
- Frecuencia > 3 posts/día
- Links directos en cada post
```

---

## Herramientas de scheduling

| Herramienta | Plataformas | Coste gratis |
|------------|-------------|-------------|
| Buffer | TW, LI, IG, FB | 10 posts |
| n8n | Todas (APIs) | €0 (self-hosted) |
| Cron + scripts | Todas (APIs) | €0 |
| Mastodon API | Mastodon | <|url_placeholder|> |

---

## Próximo capítulo

→ **[06-IA-Workflows.md](06-IA-Workflows.md)** — Integra IA generativa en tus automatizaciones.
