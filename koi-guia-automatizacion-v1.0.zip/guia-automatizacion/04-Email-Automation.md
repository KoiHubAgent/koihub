# 📘 Capítulo 4 — Automatización de Email

## Propuestas incluidas

### 4.1 — Respuesta automática inteligente

```
Trigger: Nuevo email recibido
↓
Extraer: intent, urgencia, tono (con IA)
↓
Generar: borrador de respuesta (con IA)
↓
Acción: Guardar en borradores O enviar directamente
```

### 4.2 — Email de bienvenida (Gumroad webhook)

```
Trigger: Compra en Gumroad (webhook)
↓
Delay: Inmediato
↓
Acción: Enviar email de bienvenida + link de descarga
↓
Delay: 3 días
↓
Acción: Enviar "¿Cómo vas?" + CTA review
```

### 4.3 — Newsletter semanal automática

```
Trigger: Cada viernes a las 10am (cron)
↓
Contenido: Últimos artículos/publicaciones
↓
Generar: Con IA (compilar en email coherente)
↓
Enviar: A lista de suscriptores
```

---

## Implementación: Gmail + App Password

Para automatizar Gmail necesitas una "App Password":

1. Ve a [myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords)
2. Genera una app password para "Mail"
3. Guárdala en credentials.json

### Script: Respuesta automática con IA

```bash
#!/bin/bash
# email-auto-reply.sh
set -euo pipefail

CREDS="$HOME/.openwork/credentials.json"
LOG="$HOME/.openwork/logs/email.log"
GMAIL_USER=$(jq -r '.gmail_user' "$CREDS")
GMAIL_PASS=$(jq -r '.gmail_app_password' "$CREDS")
OPEN_KEY=$(jq -r '.openrouter_api_key' "$CREDS")

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG"; }

# Leer últimos emails no leídos via IMAP
# (Usa python imaplib para esto)
EMAP_OUTPUT=$(python3 << 'PYEOF'
import imaplib, email, os, json, sys

creds = json.load(open(os.path.expanduser('~/.openwork/credentials.json')))
user = creds['gmail_user']
passwd = creds['gmail_app_password']

try:
    m = imaplib.IMAP4_SSL('imap.gmail.com')
    m.login(user, passwd)
    m.select('INBOX')
    _, data = m.search(None, 'UNSEEN')
    ids = data[0].split()[-5:]  # Últimos 5 no leídos
    
    results = []
    for eid in ids:
        _, msg_data = m.fetch(eid, '(RFC822)')
        msg = email.message_from_bytes(msg_data[0][1])
        body = ""
        if msg.is_multipart():
            for part in msg.walk():
                if part.get_content_type() == "text/plain":
                    body = part.get_payload(decode=True).decode('utf-8', errors='ignore')[:500]
                    break
        else:
            body = msg.get_payload(decode=True).decode('utf-8', errors='ignore')[:500]
        
        results.append({
            "from": msg['From'],
            "subject": msg['Subject'],
            "body": body
        })
    
    print(json.dumps(results))
    m.logout()
except Exception as e:
    print(json.dumps({"error": str(e)}))
    sys.exit(1)
PYEOF
)

# Procesar cada email no leído
echo "$EMAP_OUTPUT" | python3 -c "
import json, sys, os, subprocess

emails = json.load(sys.stdin)
if isinstance(emails, dict) and 'error' in emails:
    print(f'Error: {emails[\"error\"]}')
    sys.exit(1)

for em in emails:
    print(f\"De: {em['from']} | Asunto: {em['subject']}\")
    # Aquí podrías llamar a OpenRouter para generar respuesta
    # y guardarla en borradores o enviarla
" >> "$LOG" 2>&1

log "📧 Procesados $(echo "$EMAP_OUTPUT" | python3 -c "import json,sys; print(len(json.load(sys.stdin)))") emails"
```

---

## Implementación: Newsletter con Markdown → HTML

```bash
#!/bin/bash
# newsletter-builder.sh
# Convierte un Markdown newsletter a HTML y lo envía via SMTP

INPUT_MD="$1"
OUTPUT_HTML="${INPUT_MD%.md}.html"

# Convertir Markdown a HTML (con pandoc o python-markdown)
python3 -c "
import markdown
with open('$INPUT_MD') as f:
    html = f.read()
print(markdown.markdown(html, extensions=['tables', 'fenced_code']))
" > "$OUTPUT_HTML"

echo "✅ Newsletter generada: $OUTPUT_HTML"
echo "Envía con: msmtp, mutt, o tu API de email preferida"
```

---

## Integración con Gumroad

```bash
# Gumroad webhook handler (en webhook-server.js)
const express = require('express');
const nodemailer = require('nodemailer');

app.post('/webhook/gumroad', async (req, res) => {
  const { email, product_name, price } = req.body;
  
  // Enviar email de bienvenida
  await transporter.sendMail({
    from: 'koi@koihub.com',
    to: email,
    subject: `¡Gracias por comprar ${product_name}! 🎏`,
    html: `<h1>¡Hola!</h1>
           <p>Gracias por tu compra de <strong>${product_name}</strong>.</p>
           <p><a href="${process.env.DOWNLOAD_LINK}">Descarga tu producto aquí</a></p>
           <p>Si tienes dudas, responde a este email.</p>
           <p>— koi 🎏</p>`
  });
  
  res.json({ status: 'ok' });
});
```

---

## Herramientas de Email gratuitas

| Herramienta | Envíos/mes | API | Ideal para |
|-------------|-----------|-----|-----------|
| Gmail SMTP | 500/día | IMAP + SMTP | Automatización personal |
| Mailgun | 5,000/mes | REST | Apps/webhooks |
| Resend | 3,000/mes | REST | Newsletters |
| Brevo | 300/día | REST | Marketing |
| Amazon SES | 62,000/mes | SMTP + REST | Volumen alto |

---

## Próximo capítulo

→ **[05-Social-Media.md](05-Social-Media.md)** — Automatiza publicaciones en redes sociales.
