# 📘 Capítulo 6 — Workflows con IA Generativa

## Concepto: IA como nodo en tu flujo de automatización

La IA no reemplaza tu automatización — **la hace inteligente.**

**Sin IA:**
```
Email recibido → Respuesta estándar (template)
```

**Con IA:**
```
Email recibido → IA analiza intent → IA genera respuesta personalizada
```

---

## Patrones comunes

### Patrón 1: Clasificador
```
Input → IA clasifica → Ruta A o Ruta B
```
Ejemplo: Email → ¿es queja, pregunta o spam? → Acción diferente

### Patrón 2: Generador
```
Trigger → IA procesa datos → Genera output

Ejemplo: Idea de post → IA escribe tweet/linkedin

### Patrón 3: Agente (multi-paso)
```

Objetivo → IA planifica → Ejecuta paso 1 → Evalúa → Paso 2 …→ Resultado

```

---

## Integración con OpenRouter desde Bash

```bash
#!/bin/bash
# ai-helper.sh — Helper genérico para llamar OpenRouter

CREDS="$HOME/.openwork/credentials.json"
OPEN_KEY=$(jq -r '.openrouter_api_key' "$CREDS")

ai_call() {
  local prompt="$1"
  local system="${2:-Eres un asistente útil y conciso.}"
  local model="${3:-openrouter/auto}"

  curl -s https://openrouter.ai/api/v1/chat/completions \
    -H "Authorization: Bearer $OPEN_KEY" \
    -H "Content-Type: application/json" \
    -d "{
      \"model\": \"$model\",
      \"messages\": [
        {\"role\": \"system\", \"content\": \"$system\"},
        {\"role\": \"user\", \"content\": \"$prompt\"}
      ],
      \"max_tokens\": 800
    }" | jq -r '.choices[0].message.content'
}

# Uso:
# ai_call "Resume este texto: $(cat ../tareas.md)"
# ai_call "Clasifica: '"$EMAIL"'" "Responde solo con JSON"
```

---

## Workflow completo: Generador de contenido semanal

```bash
#!/bin/bash
# weekly-content-gen.sh
# Genera contenido para toda la semana con IA

set -euo pipefail
source "$HOME/.openwork/scripts/ai-helper.sh"

TOPIC="${1:-automatización con IA}"
OUTPUT_DIR="$HOME/.openwork/content-queue"
mkdir -p "$OUTPUT_DIR"

# LUNES
LUNES=$(ai_call "Genera 1 tweet y 1 post de LinkedIn sobre '$TOPIC' para un lunes. Tweet: ≤280 chars, sin hashtags de marketing. LinkedIn: ≤1300 chars, tono educativo. Formato:\n---TWEET---\n{tweet}\n---LINKEDIN---\n{linkedin}")

echo "# Lunes" > "$OUTPUT_DIR/monday.md"
echo "- 09:00 → twitter: $(echo "$LUNES" | grep -A1 "TWEET" | tail -1)" >> "$OUTPUT_DIR/monday.md"
echo "- 18:00 → linkedin: $(echo "$LUNES" | grep -A10 "LINKEDIN" | tail -n +2 | head -5)" >> "$OUTPUT_DIR/monday.md"

echo "✅ Contenido semanal generado en $OUTPUT_DIR"
```

---

## Costes de IA gratuita

Con OpenRouter free tier:

| Modelo | Calidad | Velocidad | Llamadas gratis/día |
|--------|---------|-----------|---------------------|
| `openrouter/auto` | Alta | Media | 50 |
| `google/gemini-2.5-flash` | Alta | Rápida | 50 |
| `deepseek/deepseek-v4-flash:free` | Muy alta | Media | 50 |
| `nvidia/nemotron-3-super-120b-a12b:free` | Muy alta | Media | 50 |

**Para automatización personal:** más que suficiente con el tier gratuito.

---

## Próximo capítulo

→ **[07-Workers-Bash.md](07-Workers-Bash.md)** — Scripts bash para workers automatizados (basados en los koi-worker reales).
