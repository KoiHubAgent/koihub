# 📘 Capítulo 3 — Tu Primera Automatización (Paso a Paso)

## Proyecto: Resumen diario de tareas pendientes

Vamos a construir un sistema que cada mañana te envíe por Telegram las tareas que tienes pendientes.

**Stack:** Bash + Cron + OpenRouter API + Telegram Bot
**Coste:** €0
**Tiempo de implementación:** 20 minutos
**RAM:** ~0.1MB

---

## Paso 1: Preparar el entorno

```bash
# Crear carpeta de trabajo
mkdir -p ~/.openwork/workers ~/.openwork/logs
touch ~/.openwork/tareas.md

# Guardar credenciales
cat > ~/.openwork/credentials.json << 'EOF'
{
  "openrouter_api_key": "tu-key-aqui",
  "telegram_bot_token": "tu-token-aqui",
  "telegram_chat_id": "tu-chat-id"
}
EOF
chmod 600 ~/.openwork/credentials.json
```

---

## Paso 2: Crear la lista de tareas

```bash
cat > ~/.openwork/tareas.md << 'EOF'
# Tareas Pendientes

## 🔴 Alta prioridad
- [ ] Configurar backups del servidor
- [ ] Publicar artículo en Dev.to
- [ ] Responder emails de clientes

## 🟡 Media prioridad
- [ ] Actualizar documentación del proyecto
- [ ] Revisar métricas de ventas
- [ ] Planificar contenido de la semana

## 🟢 Baja prioridad
- [ ] Explorar nuevas plataformas freelance
- [ ] Organizar archivos del workspace
EOF
```

---

## Paso 3: El worker

```bash
#!/bin/bash
# ~/.openwork/workers/daily-reminder.sh
# Envía resumen de tareas cada mañana vía Telegram

set -euo pipefail

CREDS="$HOME/.openwork/credentials.json"
TASKS="$HOME/.openwork/tareas.md"
LOG="$HOME/.openwork/logs/daily-reminder.log"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG"; }

# Leer credenciales
OPEN_KEY=$(jq -r '.openrouter_api_key' "$CREDS")
TG_TOKEN=$(jq -r '.telegram_bot_token' "$CREDS")
TG_CHAT=$(jq -r '.telegram_chat_id' "$CREDS")

# Leer tareas
TASKS_CONTENT=$(cat "$TASKS" 2>/dev/null || echo "Sin tareas pendientes")

# Generar resumen con IA
RESUMEN=$(curl -s https://openrouter.ai/api/v1/chat/completions \
  -H "Authorization: Bearer $OPEN_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "openrouter/auto",
    "messages": [{
      "role": "user",
      "content": "Lee estas tareas y genera un resumen motivacional de ~150 palabras para empezar el día. Destaca las de alta prioridad. Tono: directo, humano, motivador. No inventes tareas.\n\n'"$TASKS_CONTENT"'"
    }],
    "max_tokens": 400
  }' | jq -r '.choices[0].message.content' 2>/dev/null || echo "Tener un buen día. Revisa tus tareas pendientes.")

# Enviar mensaje
Mensaje="🎏 *Buenos días!*\n\n$RESUMEN\n\n_Para actualizar: edita ~/.openwork/tareas.md_"

curl -s "https://api.telegram.org/bot$TG_TOKEN/sendMessage" \
  -d "chat_id=$TG_CHAT" \
  -d "parse_mode=Markdown" \
  -d "text=$Mensaje" >> "$LOG" 2>&1

log "✅ Resumen diario enviado"
```

```bash
chmod +x ~/.openwork/workers/daily-reminder.sh
```

---

## Paso 4: Programar con cron

```bash
# Editar crontab
crontab -e

# Añadir esta línea (todos los días a las 8am):
0 8 * * * /home/tuuser/.openwork/workers/daily-reminder.sh
```

---

## Paso 5: Probar

```bash
# Ejecutar manualmente
bash ~/.openwork/workers/daily-reminder.sh

# Verificar log
tail -f ~/.openwork/logs/daily-reminder.log

# Verificar que Telegram recibió el mensaje
```

---

## ¿Qué lograste?

Tienes ahora un sistema que:
- ✅ Lee tareas de un archivo Markdown fácil de editar
- ✅ Genera un resumen con IA (no es solo una lista seca)
- ✅ Te lo envía al móvil cada mañana automáticamente
- ✅ Funciona por €0
- ✅ Consume ~0.1MB de RAM

---

## Adaptaciones posibles

| Quiero que... | Modifico... |
|---|---|
| Se ejecute a otra hora | El cron |
| Use otra fuente de tareas (API, Trello) | El worker, sección "Leer tareas" |
| Envíe a Discord en vez de Telegram | URL + payload del `curl` final |
| Incluya el tiempo/weather | Añadir llamada a wttr.in antes del send |
| Solo envíe si hay tareas | Añadir condición `if grep -q "\[ \]" ...` |

---

## Próximo capítulo

→ **[04-Email-Automation.md](04-Email-Automation.md)** — Automatiza respuestas de email y newsletters.
