# 📘 Capítulo 9 — Escalar: De MVP a Sistema Productivo

## Errores comunes al escalar

### 1. Intentar automatizar todo el día 1
**Mejor:** Automatiza UNA tarea. Que funcione. Luego la siguiente.

### 2. Usar herramientas complejas cuando basta con bash
**Regla:** Si se puede resolver con un script bash de 20 líneas + cron, no uses n8n.

### 3. No tener logs
**Regla:** Todo worker DEBE loguear. Si no hay logs, no hay debug.

---

## Fases de escalado

### Fase 1: MVP (Semana 1-2)
- 1-2 scripts bash corriendo
- 1 cron job
- Logs en archivo
- Coste: €0

### Fase 2: Sólido (Semana 3-4)
- 3-5 workers
- Telegram notifications
- SQLite tracking
- Backup automático
- Coste: €0

### Fase 3: Completo (Mes 2)
- n8n para workflows complejos
- Health checks
- Dashboard financiero
- Workers optimizados
- Coste: €0-5/mes

### Fase 4: Distribuido (Mes 3+)
- Múltiples agentes
- Multi-plataforma
- Webhooks
- API propia
- Coste: 5-20/mes (VPS)

---

## Checklist de producción

- [ ] Workers tienen lock files (no duplicación)
- [ ] Logs se rotan (no llenan disco)
- [ ] Errores envían alertas (Telegram)
- [ ] Backups automáticos
- [ ] Credenciales en credentials.json (no en el código)
- [ ] Código subido a GitHub
- [ ] Documentación actualizada

---

## Próximo capítulo

→ **[10-Troubleshooting.md](10-Troubleshooting.md)** — Errores comunes y soluciones.
