# 📘 Capítulo 1 — Conceptos Básicos de Automatización

## ¿Qué es automatización?

Automatización = **Una regla que ejecuta una acción cuando se cumple una condición.**

```
SI pasa X → ENTONCES haz Y
```

Ejemplos reales:

| Si (trigger) | Entonces (acción) |
|---|---|
| Recibo un email de un cliente | Crear un ticket de soporte |
| Es lunes a las 9am | Generar post para LinkedIn |
| Alguien compra en Gumroad | Enviar email de bienvenida |
| El servidor tiene >90% CPU | Enviar alerta al admin |
| Pasa 1 día desde última publicación | Publicar contenido programado |

---

## ¿Por qué automatizar?

La respuesta corta: **multiplicas tu tiempo.**

Sin automatización:
- Publicar 1 post = 30 min de trabajo manual
- Publicar 7 posts/semana = 3.5 horas perdidas

Con automatización:
- Preparas 7 posts en 1 hora (batch)
- El sistema publica automáticamente
- Ahorras **2.5 horas/semana** = **10 horas/mes**

Ahora multiplica eso por email marketing, facturación, soporte, backups, monitoreo...

---

## Tipos de automatización

### 1. Simple (Trigger → Acción)
```
Si hay nuevo email → Guardar attachment en carpeta
```

### 2. Multi-paso (Trigger → Acción₁ → Acción₂ → ...)
```
Si alguien se registra → Enviar welcome → Esperar 3 días → Enviar CTA
```

### 3. Condicional (Si X → A, Si Y → B)
```
Si email contiene "urgente" → Alerta inmediata
Si email contiene "newsletter" → Archivar
Si otro → Bandeja normal
```

### 4. Agente autónomo (Bucle inteligente)
```
Monitorear → Decidir → Actuar → Evaluar → Repetir
```

---

## Elementos de cualquier automatización

```
┌──────────┐    ┌──────────┐    ┌──────────┐
│ TRIGGER  │───▶│ LOGICA   │───▶│  ACCIÓN  │
│ (evento) │    │ (filtros) │    │ (output) │
└──────────┘    └──────────┘    └──────────┘
```

- **Trigger:** Qué evento dispara el flujo (cron, webhook, email, hora, etc.)
- **Lógica:** Filtros, condiciones, transformaciones
- **Acción:** Qué se hace (enviar email, publicar, guardar, alertar...)

---

## Herramientas del ecosistema gratuito

| Función | Herramienta | Coste |
|---------|-------------|-------|
| Workflows | n8n (self-hosted) | €0 |
| Scheduling | cron / systemd timers | €0 |
| Scripts | Bash | €0 |
| IA/LLM | OpenRouter (free models) | €0 |
| Hosting scripts | GitHub / Gist | €0 |
| Monitoreo | Uptime Kuma (self-hosted) | €0 |
| Hosting web | GitHub Pages / Netlify | €0 |
| Base de datos | SQLite / JSON files | €0 |
| Notificaciones | Pushover / Telegram Bot | €0 |
| Tracking | Plausible (self-hosted) | €0 |

No necesitas AWS. No necesitas pagar. Necesitas saber conectar las piezas.

---

## Mentalidad: "¿Se puede automatizar?"

Antes de hacer cualquier tarea manual, pregúntate:

1. **¿Repito esto más de 3 veces por semana?**
2. **¿Sigo siempre los mismos pasos?**
3. **¿Hay un trigger claro?**
4. **¿El resultado es predecible?**

Si respondes SÍ a las 4 → **AUTOMATÍZALO.**

Si respondes NO a alguna → puede que no valga la pena (YAGNI: You Ain't Gonna Need It).

---

## Próximo capítulo

→ **[02-Herramientos.md](02-Herramientas.md)** — Catálogo de herramientas gratuitas con instrucciones de setup.
