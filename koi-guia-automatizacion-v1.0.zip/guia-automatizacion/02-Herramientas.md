# 📘 Capítulo 2 — Herramientas Gratuitas y Cómo Configurarlas

## El stack gratuito completo

Esto es todo lo que necesitas automatizar tu negocio digital por €0/mes:

---

## 1. n8n — Workflows Visuales

**Qué es:** Automatización visual tipo Zapier, pero self-hosted y gratis.
**Por qué:** No hay límite de ejecuciones, no hay costes por uso.
**RAM:** ~600MB (mucho, pero manejable en cualquier VPS básico).

### Instalación (Node.js):

```bash
npm install n8n -g
n8n start
# Abre http://localhost:5678
```

### Docker (recomendado):

```bash
docker run -d \
  --name n8n \
  -p 5678:5678 \
  -v n8n_data:/home/node/.n8n \
  n8nio/n8n
```

### Alternativa ligera: Webhook server en Node.js

Si n8n consume demasiada RAM, usa un mini servidor:

```javascript
// webhook-server.js
const express = require('express');
const app = express();
app.use(express.json());

app.post('/webhook/:action', (req, res) => {
  const { action } = req.params;
  console.log(`[${action}]`, req.body);
  // Tu lógica aquí
  res.json({ status: 'ok' });
});

app.listen(5679, () => console.log('Webhook server en :5679'));
```

**RAM:** 0.5MB vs 600MB de n8n.

---

## 2. Cron / Systemd Timers — Scheduling

**Qué es:** El programador de tareas del sistema.
**Por qué:** Ligero, nativo, 0 dependencias.

### Cron básico:

```bash
# Editar crontab
crontab -e

# Ejemplos:
# Cada 6 horas:
0 */6 * * * /ruta/al/script.sh

# Lunes a viernes a las 9am:
0 9 * * 1-5 /ruta/al/script.sh

# Cada domingo a las 6pm:
0 18 * * 0 /ruta/al/script.sh
```

### Systemd timer (más robusto):

```ini
# ~/.config/systemd/user/mi-timer.timer
[Unit]
Description=Mi automatización periódica

[Timer]
OnCalendar=*-*-* 09:00:00
Persistent=true

[Install]
WantedBy=timers.target
```

```bash
systemctl --user daemon-reload
systemctl --user enable --now mi-timer.timer
systemctl --user list-timers
```

---

## 3. Bash Scripts — Workers Automatizados

**Qué es:** Scripting nativo de Linux.
**Por qué:** Máximo control, 0 dependencias, runs en ~0.1MB RAM.

### Template base para workers:

```bash
#!/bin/bash
# mi-worker.sh - Plantilla base
set -euo pipefail

LOG="$HOME/.openwork/mi-worker.log"
MAX_LOG_LINES=10000

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG"; }

rotate_log() {
  local lines=$(wc -l < "$LOG" 2>/dev/null || echo 0)
  if [ "$lines" -gt "$MAX_LOG_LINES" ]; then
    tail -n $((MAX_LOG_LINES / 2)) "$LOG" > "${LOG}.tmp"
    mv "${LOG}.tmp" "$LOG"
  fi
}

log "🚀 Iniciando worker..."
# === TU LÓGICA AQUÍ ===
log "✅ Worker completado"
rotate_log
```

---

## 4. OpenRouter — IA Gratuita

**Qué es:** Gateway unificado para modelos de IA gratuitos.
**Por qué:** GPT-4 quality a coste 0.

### Setup:

1. Crea cuenta en [openrouter.ai](https://openrouter.ai)
2. Genera API key
3. Usa desde scripts:

```bash
curl -s https://openrouter.ai/api/v1/chat/completions \
  -H "Authorization: Bearer $OPENROUTER_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "openrouter/auto",
    "messages": [{"role": "user", "content": "Tu prompt aquí"}]
  }'
```

### Modelos gratuitos que funcionan:

- `openrouter/auto` — Selecciona el mejor gratis automáticamente
- `google/gemini-2.5-flash` — Rápido y bueno
- `openrouter/nvidia/nemotron-3-super-120b-a12b:free` — Potente y gratis
- `openrouter/deepseek/deepseek-v4-flash:free` — Alta calidad

---

## 5. Telegram Bot — Notificaciones

**Qué es:** Bot para recibir alertas de tus automatizaciones.
**Por qué:** Instantáneo, gratis, push al móvil.

### Setup:

1. Habla con @BotFather en Telegram → `/newbot`
2. Guarda el token
3. Envía mensaje desde bash:

```bash
# Enviar notificación
curl -s "https://api.telegram.org/bot<TOKEN>/sendMessage" \
  -d "chat_id=<CHAT_ID>&text=Mi automatización completada ✅"
```

---

## 6. GitHub — Backup y Versionado

**Qué es:** Almacenamiento de código con historial.
**Por qué:** Tus scripts sobreviven a un fallo de disco.

```bash
# Setup una vez
cd ~/.openwork
git init
git remote add origin git@github.com:tuuser/scripts.git
echo '*.log' > .gitignore
echo 'credentials.json' >> .gitignore

# Backup automático (diario)
git add .
git commit -m "Backup $(date +%Y-%m-%d)"
git push
```

---

## 7. SQLite — Base de Datos Ligera

**Qué es:** Base de datos en un fichero, sin servidor.
**Por qué:** Tracking de ingresos, clientes, logs — todo organizada.

```bash
# Crear DB
sqlite3 ~/.openwork/tracking.db "CREATE TABLE ingresos (
  id INTEGER PRIMARY KEY,
  fecha TEXT NOT NULL,
  fuente TEXT NOT NULL,
  monto REAL NOT NULL,
  moneda TEXT DEFAULT 'EUR',
  descripcion TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);"

# Insertar dato
sqlite3 ~/.openwork/tracking.db \
  "INSERT INTO ingresos (fecha, fuente, monto, descripcion) \
   VALUES ('2026-05-30', 'Gumroad', 29.00, 'Venta n8n-prompt-pack');"
```

---

## Checklist de Setup

- [ ] n8n instalado O webhook-server.js corriendo
- [ ] Crontab con workers configurados
- [ ] API key de OpenRouter guardada
- [ ] Telegram bot para notificaciones
- [ ] Repo GitHub con backup de scripts
- [ ] SQLite para tracking

---

## Próximo capítulo

→ **[03-Primer-Workflow.md](03-Primer-Workflow.md)** — Tu primera automatización completa, paso a paso.
