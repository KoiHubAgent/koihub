# 📘 Capítulo 10 — Troubleshooting

## Errores más comunes

### 1. "Permission denied"
```bash
chmod +x mi-script.sh
```

### 2. "Command not found"
```bash
# Ver si está instalado
which jq || sudo dnf install jq

# Ver si PATH incluye el dir
echo $PATH
export PATH="$HOME/.local/bin:$PATH"
```

### 3. Cron no ejecuta
```bash
# Verificar que cron corre
systemctl status crond

# Usar rutas absolutas en cron
# MAL: bash script.sh
# BIEN: bash /home/user/.openwork/workers/script.sh

# Redirigir output para debug
0 8 * * * bash /ruta/script.sh >> /ruta/cron.log 2>&1
```

### 4. API rate limits (429)
```bash
# Añadir reintentos con backoff
retry_call() {
  local n=1
  local max=3
  local delay=5
  while true; do
    "$@" && break || {
      if [[ $n -lt $max ]]; then
        echo "⚠️ Intento $n fallido. Reintentando en ${delay}s..."
        sleep $delay
        n=$((n+1))
        delay=$((delay*2))
      else
        echo "❌ Error después de $max intentos"
        return 1
      fi
    }
  done
}

# Uso:
# retry_call curl -s "https://api.example.com/endpoint"
```

### 5. Worker se repite infinitamente
```bash
# Lock file (ya incluido en el template)
if [ -f "/tmp/mi-worker.lock" ]; then
  exit 0  # Ya corriendo
fi
touch "/tmp/mi-worker.lock"
trap 'rm -f "/tmp/mi-worker.lock"' EXIT
```

### 6. Credenciales expiradas
- OpenRouter keys: Renovar cada ~30 días
- Telegram tokens: No expiran
- Gmail App Passwords: Si cambias la contraseña de Gmail, regenera
- API keys de redes sociales: Tienen distintos ciclos de expiración

### 7. "Out of memory"
```bash
# Ver qué consume memoria
free -htop

# Matar procesos que consuman demasiado
pkill -f n8n  # Si n8n consume demasiado

# Configurar swap si no tienes
sudo fallocate -l 2G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
```

---

## Debugging checklist

1. ¿El script tiene permisos de ejecución? (`chmod +x`)
2. ¿Las rutas son absolutas? (nunca relativas en cron)
3. ¿Las credenciales existen y son válidas?
4. ¿Hay conectividad de red? (`ping 8.8.8.8`)
5. ¿Hay disco disponible? (`df -h`)
6. ¿El log dice algo? (`tail -f ~/.openwork/logs/`)
7. ¿El worker tiene lock viejo? (`rm /tmp/worker.lock`)
8. ¿Hay rate limits? (esperar 60s y reintentar)

---

## Recursos útiles

- `man cron` — Documentación de cron
- `man systemd.timer` — Documentación de timers
- [Explain Shell](https://explainshell.com) — Pasa un comando y te lo explica
- [ShellCheck](https://www.shellcheck.net) — Valida tus scripts bash
- [Crontab.guru](https://crontab.guru) — Visualizador de expresiones cron

---

_Fin de la guía. ¡A automatizar! 🎏_
