# 🌐 Landing Page Template para Productos IA

**Versión 1.0** | Mayo 2026

---

## 📋 Qué incluye

Una landing page completa, moderna y lista para personalizar, diseñada específicamente para vender productos digitales de IA/automatización.

**Stack:**
- HTML5 semántico
- CSS custom properties (fácil personalización de colores/fuentes)
- JavaScript vanilla (sin dependencias externas)
- Google Fonts (Inter)
- 100% responsive

---

## 🗂️ Estructura

```
landing-page-template/
├── index.html          # Página completa con secciones modulares
├── css/
│   └── style.css       # Estilos completos con variables CSS
├── js/
│   └── main.js         # Interacciones (nav, scroll, tracking)
└── README.md           # Este archivo (con guía de personalización)
```

---

## 🚀 Cómo personalizar (5 minutos)

### 1. Variables de colores (CSS)
Abre `css/style.css` y modifica `:root`:

```css
--primary: #6366f1;        /* Color principal (botones, links) */
--bg: #0a0a0b;             /* Fondo principal */
--text: #e4e4e7;           /* Texto principal */
--radius: 12px;            /* Redondeo de bordes */
```

### 2. Contenido (HTML)
En `index.html`, reemplaza las variables `{{COMO_ESTAS}}` con tu contenido:

| Variable | Sección | Qué poner |
|----------|---------|-----------|
| `{{PRODUCT_NAME}}` | Todas | Tu nombre de producto |
| `{{BRAND_NAME}}` | Nav/Footer | Tu marca |
| `{{HERO_HEADLINE}}` | Hero | Titular principal |
| `{{HERO_SUBTITLE}}` | Hero | Subtítulo explicativo |
| `{{CTA_TEXT}}` | Hero/Pricing | Texto del botón (ej: "Comprar $29") |
| `{{CTA_LINK}}` | Hero/Pricing | Link de compra (Gumroad, Stripe...) |
| `{{FEATURES}}` | Features | Array de features (icon + title + desc) |

### 3. Desplegar
Opciones gratuitas:
- **GitHub Pages**: Sube el repo → Settings → Pages → Main branch
- **Netlify Drop**: Arrastra la carpeta a [app.netlify.com/drop](https://app.netlify.com/drop)
- **Vercel**: `vercel deploy`

---

## ✅ Secciones incluidas

1. **Nav** — Fija, blur, responsive con hamburguesa
2. **Hero** — Badge, headline, subtitle, CTAs duales, trust line, proof icons
3. **Barra social proof** — Nº usuarios, rating, testimonios
4. **Problema** — 3 pain points + frase puente
5. **Features** — Grid de features con iconos y tags
6. **Beneficios** — Comparativa Antes/Después visual
7. **Cómo funciona** — Steps numerados
8. **Testimonios** — Cards con citas, estrellas, avatares
9. **Precios** — Hasta 3 planes con plan destacado
10. **FAQ** — Acordion nativo (`<details>`)
11. **CTA Final** — Cierre con garantía
12. **Footer** — Links, legal, branding

---

## 🏷️ Etiquetas

`landing-page` · `template` · `HTML/CSS` · `producto digital` · `Gumroad` · `IA`

---

_Licencia MIT — Úsalo, modifícalo, véndelo._
_Creado por koi 🎏 | Koihub © 2026_
