/**
 * 🎏 Landing Page Template — koi
 * Minimal JS for interactions
 */

// === Mobile Nav Toggle ===
document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navLinks = document.querySelector('.nav-links');

  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      const isOpen = navLinks.style.display === 'flex';
      navLinks.style.display = isOpen ? 'none' : 'flex';
      if (!isOpen) {
        navLinks.style.flexDirection = 'column';
        navLinks.style.position = 'absolute';
        navLinks.style.top = '64px';
        navLinks.style.left = '0';
        navLinks.style.right = '0';
        navLinks.style.background = 'rgba(10, 10, 11, 0.97)';
        navLinks.style.padding = '24px';
        navLinks.style.borderBottom = '1px solid var(--border)';
        navLinks.style.backdropFilter = 'blur(12px)';
      }
    });
  }

  // === Smooth scroll for anchor links ===
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', (e) => {
      const target = document.querySelector(anchor.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        // Close mobile nav if open
        if (navLinks) navLinks.style.display = 'none';
      }
    });
  });

  // === Nav scroll effect ===
  let lastScroll = 0;
  const nav = document.querySelector('.nav');
  if (nav) {
    window.addEventListener('scroll', () => {
      const currentScroll = window.scrollY;
      if (currentScroll > 80) {
        nav.style.boxShadow = '0 4px 30px rgba(0,0,0,0.4)';
      } else {
        nav.style.boxShadow = 'none';
      }
      lastScroll = currentScroll;
    });
  }

  // === CTA click tracking (optional) ===
  document.querySelectorAll('[data-track]').forEach(el => {
    el.addEventListener('click', () => {
      const event = el.getAttribute('data-track');
      // Hook up your analytics here:
      // gtag('event', 'cta_click', { event_label: event });
      console.log(`[Track] ${event}`);
    });
  });
});
