# 🎛️ n8n Prompt Pack — 50+ Prompts Organizados

---

## 📝 1. Generación de Contenido (1-12)

### 1.1 — Generador de Tweets

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.8

```
Escribe un tweet sobre: {{ $json.topic }}
Tono: {{ $json.tone || "casual y profesional" }}
Audiencia: {{ $json.audience || "emprendedores tech" }}
- Máximo 280 caracteres
- Sin hashtags
- Incluye un hook en la primera línea
- Termina con pregunta o llamada a la acción
```

### 1.2 — Generador de LinkedIn Posts

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.7

```
Escribe un post de LinkedIn sobre: {{ $json.topic }}
Formato:
- Primera línea: hook fuerte (pregunta o afirmación provocadora)
- 3-5 puntos clave en párrafos cortos
- Cada párrafo máximo 2 líneas
- Última línea: pregunta al lector
- Entre párrafos: línea en blanco
- Tono humano, conversacional
- Sin emojis excesivos (máximo 3-5)
- Máximo 1300 caracteres
```

### 1.3 — Generador de Blog Intro

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.6

```
Escribe la introducción (primeros 2-3 párrafos) de un artículo sobre:
{{ $json.title }}

El artículo responde a: {{ $json.problem }}

Estilo:
- Hook: conexión emocional con el problema del lector
- Contexto: por qué esto importa AHORA
- Promesa: qué aprenderá el lector
- Tono: directo, sin relleno
- Máximo 200 palabras
```

### 1.4 — Generador de Descripciones de Producto

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.7

```
Genera la descripción de un producto digital:
Nombre: {{ $json.product_name }}
Precio: {{ $json.price }}
Audiencia: {{ $json.audience }}

Formato de salida:
3 líneas de impacto emocional (qué problema resuelve)
--- (separador)
Qué incluye (bullets, máximo 5)
--- (separador)
¿Para quién es? (2-3 perfiles)

Tono: como le explicarías a un amigo
```

### 1.5 — Generador de Newsletter Subject Lines

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.9

```
Genera 10 opciones de asunto de email para newsletter.

Contenido del email: {{ $json.summary }}
Audiencia: {{ $json.audience || "profesionales tech" }}

Reglas:
- Máximo 50 caracteres por opción
- Sin mayúsculas excesivas
- Sin exclamaciones
- 2-3 deben generar curiosidad
- 2-3 deben ser directas
- 2-3 deben ser personales
- Númerálas del 1 al 10
```

### 1.6 — Generador de Hooks de Artículos

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.9

```
Genera 5 ganchos/hooks de apertura para un artículo titulado:
"{{ $json.title }}"

La tesis principal es: {{ $json.thesis }}

Cada hook en un estilo diferente:
1. Estadística sorprendente
2. Pregunta provocadora
3. Historia/anécdota (1 frase)
4. Declaración contraintuitiva
5. Analogía

Máximo 20 palabras cada uno.
```

### 1.7 — Generador de Email de Ventas (Soft)

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.6

```
Escribe un email de recomendación de producto.

Producto: {{ $json.product }}
Precio: {{ $json.price }}
Problema que resuelve: {{ $json.problem }}

Formato:
- Asunto: {{ $json.subject_line }} (ya generado)
- Apertura: personal, no genérica
- Historia: cómo encontraste/usaste el producto (1 párrafo)
- Valor: qué resultado obtuviste
- Recomendación: recomendación genuina (no manipuladora)
- CTA: sutil, sin presión
- Firma casual

Tono: email de un amigo, no de un vendedor
Máximo 200 palabras
```

### 1.8 — Generador de Thread de Twitter/X

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.7

```
Genera un thread de {{ $json.num_tweets || 5 }} tweets sobre:
{{ $json.topic }}

Tesis central: {{ $json.thesis }}

Formato:
- Tweet 1: hook fuerte (esto cambia todo / lo que nadie te dice)
- Tweets 2-N-1: un punto clave cada uno
- Último tweet: resumen + CTA
- Cada tweet ≤ 280 caracteres
- Numerá-los: [1/N], [2/N], etc.
- Que puedan funcionar individualmente

Tono: educativo, transparente, directo
```

### 1.9 — Generador de FAQ para Productos

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.5

```
Genera 10 preguntas frecuentes (FAQ) para:

Producto: {{ $json.product }}
Descripción: {{ $json.description }}
Precio: {{ $json.price }}
Audiencia: {{ $json.audience }}

Para cada pregunta:
- Pregunta corta y directa
- Respuesta máximo 2-3 frases
- Tono amigable, sin jerga técnica
- Formato JSON: [{"q": "...", "a": "..."}]
```

### 1.10 — Generador de Meta Descripciones SEO

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.5

```
Genera 3 opciones de meta description (SEO) para una página sobre:
{{ $json.topic }}

Palabras clave: {{ $json.keywords }}

Requisitos:
- Máximo 155 caracteres cada una
- Incluye palabra clave principal
- Genera curiosidad
- Incluye llamada a la acción implícita
```

### 1.11 — Generador de Testimonios (Base)

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.7

```
Genera 5 testimonios base para usar como referencia/solicitar editados.

Producto: {{ $json.product }}
Beneficios principales: {{ $json.beneficios }}

Formato de cada testimonio:
"[Situación antes] → [Descubrí X] → [Resultado después]"
+ Nombre ficticio
+ 1-2 frases

Estos son BASES — siempre pide a clientes reales que editen/validen.
Úsalos como plantilla para solicitar testimonios.
```

### 1.12 — Generador de Slides (Outline)

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.6

```
Genera el outline de una presentación sobre: {{ $json.topic }}
Audiencia: {{ $json.audience }}
Duración: {{ $json.slides || 10 }} slides

Formato por slide:
- Título del slide
- Punto principal (1 línea)
- Nota del presentador (1 frase opcional)

Slide 1: Hook/Tesis
Slide 2-3: Contexto/Problema
Slide 4-7: Desarrollo/Puntos clave
Slide 8-9: Ejemplos/Caso de uso
Slide 10: CTA/Cierre
```

---

## 🔧 2. Procesamiento de Datos (13-22)

### 2.13 — Parser de JSON en Email

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.1

```
Extrae datos estructurados de este email en JSON puro (sin markdown, sin explicaciones):

{{ $json.email_body }}

Formato de salida obligatorio:
{
  "intent": "<intención principal>",
  "product": "<producto mencionado o null>",
  "price_mentioned": <número o null>,
  "urgency": "<alta|media|baja>",
  "action_required": "<acción específica o null>",
  "sentimiento": "<positivo|neutral|negativo>",
  "resumen": "<1 frase>"
}
```

### 2.14 — Clasificador de Feedback

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.2

```
Clasifica este feedback sin explicar, solo JSON puro:

"{{ $json.feedback }}"

{
  "categoria": "<producto|servicio|precio|otro>",
  "sentimiento": "<positivo|neutral|negativo>",
  "prioridad": "<alta|media|baja>",
  "actionable": <true|false>,
  "resumen": "<10 palabras máximo>"
}
```

### 2.15 — Extraer Datos de Texto Libre

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.1

```
De este texto, extrae la información en JSON puro (sin markdown, sin explicaciones):

{{ $json.text }}

Extrae:
{
  "nombres": ["lista de personas mencionadas"],
  "emails": ["lista de emails"],
  "fechas": ["fechas en formato ISO: YYYY-MM-DD"],
  "numeros_clave": ["cifras importantes mencionadas"],
  "acciones": ["acciones a tomar mencionadas"]
}

Si no hay datos en una categoría, devuelve array vacío [].
```

### 2.16 — Transformador de Formato

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.1

```
Convierte esta lista en una tabla Markdown:

{{ $json.data }}

Formato: tabla Markdown con columnas claramente separadas.
```

### 2.17 — Resumen de Conversación

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.3

```
Resume esta conversación en un JSON puro (sin markdown):

{{ $json.conversation }}

{
  "topic": "<tema principal>",
  "key_decisions": ["decisión 1", "decisión 2"],
  "action_items": ["tarea 1", "tarea 2"],
  "pending": ["pendiente 1"],
  "summary": "<2 frases>"
}
```

### 2.18 — Deduplicator de Datos

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.1

```
Compara estos dos registros. ¿Son duplicados?

Registro A: {{ $json.record_a }}
Registro B: {{ $json.record_b }}

Responde JSON puro (sin markdown):
{
  "duplicado": <true|false>,
  "confianza": <0.0-1.0>,
  "razon": "<1 frase>"
}
```

### 2.19 — Traductor de Tono

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.3

```
Reescribe este texto cambiando el tono a {{ $json.target_tone }}:

"{{ $json.text }}"

Conserva toda la información cambia SOLO el estilo.
Texto reescrito (solo el texto, sin explicaciones):
```

### 2.20 — Extractor de Keywords

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.1

```
Extrae las 10 keywords más relevantes de este texto.
Responde SOLO con un array JSON, sin explicaciones:

{{ $json.text }}
```

### 2.21 — Categorizador de Productos

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.2

```
Categoriza este producto/servicio sin explicar, solo la categoría:

"{{ $json.product }}"

Categorías válidas:
- software/hardware/digital/educa/marketing/sales/design/other

Responde solo con la categoría exacta, nada más.
```

### 2.22 — Validador de Datos

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.1

```
Valida estos datos. ¿Son razonables/completos?

{{ $json.data }}

Responde JSON puro:
{
  "valido": <true|false>,
  "errores": ["error 1", "error 2"],
  "sugerencias": ["sugerencia 1"]
}
```

---

## 🎯 3. Automatización de Marketing (23-32)

### 3.23 — Generador de Lead Magnet Ideas

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.8

```
Genera 10 ideas de lead magnets para:
Nicho: {{ $json.nicho }}
Audiencia: {{ $json.audience }}
Producto principal: {{ $json.product }}

Para cada idea:
- Tipo: checklist/template/guide/template/quiz
- Título sugerido
- 1 frase de por qué funcionaría
- Formato recomendado

Prioriza ideas fáciles de crear (no requieran diseño complejo).
```

### 3.24 — Generador de Secuencia de Emails

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.7

```
Diseña una secuencia de {{ $json.num_emails || 5 }} emails de nurturing para:
Producto: {{ $json.product }}
Lead magnet descargado: {{ $json.lead_magnet }}
Audiencia: {{ $json.audience }}

Para cada email (formato JSON):
{
  "email": <número>,
  "dia": <días desde registro>,
  "asunto": "<linea de asunto>",
  "proposito": "<educación|confianza|objeción|CTA>",
  "resumen_3_frases": "<breve descripción del contenido>"
}

Secuencia lógica: Valor → Confianza → Caso de estudio → Objeciones → CTA
```

### 3.25 — Generador de A/B Test Copy

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.8

```
Crea 3 versiones A/B/C para este copy:

Contexto: {{ $json.context }}
Texto actual: {{ $json.current_copy }}

Versión A (directa y corta)
Versión B (emocional y storytelling)
Versión C (social proof + urgencia)

Máximo 30 palabras cada una.
```

### 3.26 — Generador de Títulos de Marketing

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.9

```
Genera 10 títulos para: {{ $json.landing_page_topic }}
Audiencia: {{ $json.audience }}

Patrones:
- Cómo [resultado] sin [dolor]
- El sistema de [X] que [resultado impresionante]
- [Número] formas de [beneficio]
- Por qué [creencia común] está equivocada
- De [estado actual] a [estado deseado] en [tiempo]

Máximo 60 caracteres cada uno.
```

### 3.27 — Generador de CTA (Call to Action)

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.7

```
Genera 5 opciones de CTA button text para:
Acción: {{ $json.action }} (ej: descargar, registrar, comprar)
Producto: {{ $json.product }}

Patrones a probar:
- Beneficio claro (Obtén tu guía gratis)
- Urgencia (Descarga antes de que se agote)
- Curiosidad (Descubre cómo...)
- Simple (Empezar ahora)
- Pregunta (¿Listo para...?)

Máximo 6 palabras cada CTA.
```

### 3.28 — Análisis de Competencia

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.4

```
Analiza estos 3 competidores y encuentra oportunidades:

{{ $json.competitors }}

Para cada competidor resumen:
- Fortalezas (2-3)
- Debilidades (2-3)
- Oportunidades para diferenciarte

Formato tabla competitiva.
```

### 3.29 — Generador de Valor Propuesto

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.7

```
Crea 5 versiones de propuesta de valor para:
Producto: {{ $json.product }}
Problema resuelto: {{ $json.problem }}
Resultado: {{ $json.result }}
Tiempo/sacrificio eliminado: {{ $json.elimination }}

Fórmula: "Ayudamos a [audiencia] a [resultado] sin [dolor/fricción]"
Alternativa: "El/la [producto] que [resultado] en [tiempo/condición]"

Máximo 15 palabras cada una.
```

### 3.30 — Generador de Objection Handling

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.5

```
Genera respuestas empáticas para estas 5 objeciones:

Producto: {{ $json.product }} (Precio: {{ $json.price }})

Objeciones:
1. "Es muy caro"
2. "No tengo tiempo para implementarlo"
3. "No sé si funcionará para mí"
4. "Ya intenté algo similar y no funcionó"
5. "Necesito pensarlo"

Para cada objeción:
- Validación empática (1 frase)
- Reframe/reescritura de la objeción (1-2 frases)
- Pregunta de seguimiento

NO ser combativo. Ser colaborativo.
```

### 3.31 — Generador de Welcome Sequence

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.6

```
Diseña el email de bienvenida para:
Audiencia: {{ $json.audience }}
Origen: {{ $json.source }} (lead magnet / compra / suscripción)

Email de bienvenida que:
- Confirma la acción
- Establece expectativas
- Entrega valor inmediato
- Conecta emocionalmente
- Hace una pequeña petición (respuesta, seguir en redes, etc.)

Máximo 150 palabras.
Tono: cálido, humano, emocionado de conocerles.
```

### 3.32 — Generador de Re-engagement

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.6

```
Genera 3 opciones de email de re-engagement para suscriptores inactivos.

Servicio: {{ $json.service }}
Última acción conocida: {{ $json.last_action }}

Opción 1: "Te extrañamos" (emocional)
Opción 2: "¿Sigues ahí?" (directo, curioso)
Opción 3: "Nuevo contenido + regalo" (valor)

Cada opción: asunto + preview text + cuerpo ≤ 100 palabras
```

---

## 💻 4. Generación de Código para Code Node (33-42)

### 4.33 — Generador de Código JavaScript (Code Node)

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.2

```
Escribe código JavaScript para n8n Code node que:
{{ $json.description }}

Requisitos:
- Usa `$input` para acceder a datos
- Retorna un array de objetos JSON puros
- Incluye manejo de errores con try/catch
- Sigue el formato de n8n Code node
- Comentarios mínimos pero claros

Ejemplo de estructura:
const items = $input.all();
const results = [];

// Tu código aquí

return [{ json: results }];
```

### 4.34 — Generador de Código Python (HTTP Request + Code)

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.2

```
Genera un snippet de Python que realice:
{{ $json.description }}

Requisitos:
- Usa requests si hace llamadas HTTP
- Manejo de errores con try/except
- Retorna un dict/JSON serializable
- Tipado claro en variables
- Máximo 30 líneas

Solo código, sin explicaciones.
```

### 4.35 — Generador de Expresiones n8n

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.1

```
Genera la expresión n8n (Expression) para:
{{ $json.description }}

Usa la sintaxis de n8n: {{ $json.campo }}, {{ $now }}, {{ $if() }}
Solo devuelve la expresión, sin explicaciones.
```

### 4.36 — Generador de Regex

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.1

```
Genera una expresión regular para:
{{ $json.description }}

- Solo la regex, sin delimitadores
- Explica cada parte en comentarios
- Incluye 3 ejemplos que SÍ matchean
- Incluye 2 ejemplos que NO matchean
```

### 4.37 — Generador de SQL Queries

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.2

```
Genera una query SQL para:
{{ $json.description }}

Base de datos: {{ $json.db_type || "PostgreSQL" }}

Requisitos:
- Optimizada (evita SELECT *)
- Incluye recomendación de index si aplica
- Sintaxis compatible con {{ $json.db_type || "PostgreSQL" }}
```

### 4.38 — Transformador JSON a CSV

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.1

```
Genera un snippet JavaScript para n8n Code node que:
- Recibe un array de objetos JSON
- Lo transforma en string CSV
- Maneja campos vacíos como ""
- Escapa comillas en valores

Devuelve el código del Code node listo para copiar-pegar.
```

### 4.39 — Generador de Bash Script

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.2

```
Genera un script bash que:
{{ $json.description }}

Requisitos:
- Usa `set -euo pipefail`
- Incluye comentarios claros
- Manejo de errores
- Variables en MAYÚSCULAS
- Máximo 40 líneas
```

### 4.40 — Generador de Webhook Handler

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.2

```
Genera un servidor webhook mínimo en Node.js que:
{{ $json.description }}

Requisitos:
- Usa Express.js
- Valida el método HTTP espera
- Parsea JSON body
- Log de requests
- Respuestas claras (200/400/500)

Listo para desplegar.
```

### 4.41 — Generador de API Response Formatter

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.1

```
Genera una función JavaScript que formatee la respuesta de esta API:

Endpoint: {{ $json.endpoint }}
Respuesta actual: {{ $json.sample_response }}
Campos necesarios: {{ $json.fields_needed }}

Retorna un array de objetos con SOLO los campos necesarios, renombrados según:
{{ $json.field_mapping }}
```

### 4.42 — Generador de Cron Expression Helper

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.1

```
Genera la expresión cron para:
{{ $json.description }}

Formato: min hora día-mes mes día-semana
Ejemplos:
- Cada 6 horas: 0 */6 * * *
- Lunes a viernes 9am: 0 9 * * 1-5
- Cada lunes 6pm: 0 18 * * 1

Solo la expresión cron, sin explicaciones.
```

---

## 🤖 5. Prompts para Agentes Autónomos (43-52)

### 4.43 — ReAct Agent Prompt

**Nodo:** OpenAI Chat Model (o similar agentic node)
**Temperatura:** 0.3

```
Eres un agente de investigación Socrático. Tu objetivo es:

{{ $json.objetivo }}

Reglas:
1. Piensa paso a paso (Thought)
2. Usa herramientas solo cuando necesites datos externos (Action)
3. Observa el resultado (Observation)
4. Repite hasta tener la respuesta final

Formato OBLIGATORIO:
Thought: <tu razonamiento>
Action: <herramienta> | Action Input: <input>
Observation: <resultado>
...
Thought: Ya tengo todo lo necesario.
Final Answer: <respuesta completa>
```

### 4.44 — Planner Agent Prompt

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.3

```
Eres un agente planificador. Descompón este objetivo en pasos ejecutables:

OBJETIVO: {{ $json.objective }}
CONTEXTO: {{ $json.context }}
RECURSOS: {{ $json.resources }}

Genera un plan JSON:
{
  "objetivo": "<texto>",
  "pasos": [
    {
      "id": 1,
      "descripcion": "<qué hacer>",
      "herramienta": "<qué nodo/herramienta usar>",
      "depende_de": <paso previo o null>,
      "output_esperado": "<qué produce>",
      "validacion": "<cómo verificar que está bien>"
    }
  ]
}

Dependencias explícitas entre pasos. Máximo 10 pasos.
```

### 4.45 — Reply Generator (Soporte al Cliente)

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.4

```
Eres soporte al cliente de {{ $json.company }}.
Responde a este email de un cliente:

"{{ $json.customer_message }}"

Producto/Servicio involucrado: {{ $json.product }}
Historial del cliente: {{ $json.history || "Sin historial previo" }}

Reglas:
- Empatiza primero, soluciona después
- NUNCA eches culpa al cliente
- Máximo 4 frases
- Ofrece siguiente paso concreto
- Tono humano, cálido

Si el problema requiere escalar: indica por qué y a qué departamento.
```

### 4.46 — Summarizer de Artículos

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.3

```
Resume este artículo en formato estructurado:

{{ $json.article }}

Formato:
**Título:** <título original>
**Tesis:** <1 frase — de qué trata>
**Puntos clave:** <3-5 bullets>
**Acción:** <qué debería hacer alguien tras leerlo>
**Audiencia:** <para quién es más relevante>

Máximo: 100 palabras total (excluyendo labels).
```

### 4.47 — Generador de Room Code / Session Starter

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.5

```
Genera el prompt de system para una sesión de trabajo con un agente IA.

Tipo de trabajo: {{ $json.work_type }}
Herramientas disponibles: {{ $json.tools }}
Restricciones: {{ $json.constraints || "Ninguna específica" }}

El system prompt debe ser:
- Conciso (máximo 500 palabras)
- Con reglas claras de qué hacer y qué NO hacer
- Con formato de output esperado
- Con manejo de casos de error

Solo el system prompt, sin explicaciones.
```

### 4.48 — Evaluador de Calidad

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.2

```
Evalúa el siguiente contenido en una escala de 1-10 según criterios.

Contenido: {{ $json.content }}
Tipo: {{ $json.type }} (blog/email/tweet/landing)
Criterios:
- Claridad
- Engagement potencial
- CTA efectivo
- Tono adecuado
- Originalidad

JSON puro:
{
  "scores": { "claridad": X, "engagement": X, "cta": X, "tono": X, "originalidad": X },
  "promedio": X,
  "mejoras": ["mejora 1", "mejora 2", "mejora 3"]
}
```

### 4.49 — Bug Report Analyzer

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.2

```
Analiza este reporte de bug y genera un diagnóstico:

Bug report: {{ $json.bug_report }}

JSON puro (sin markdown):
{
  "severidad": "<crítica|alta|media|baja>",
  "componente": "<qué parte del sistema>",
  "pasos_reproducir": ["paso 1", "paso 2"],
  "comportamiento_esperado": "<1 frase>",
  "comportamiento_actual": "<1 frase>",
  "posibles_causas": ["causa 1", "causa 2"],
  "sugerencia_fix": "<1 frase>"
}
```

### 4.50 — Generador de User Stories / Tickets

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.3

```
Genera tickets de trabajo a partir de este requerimiento:

"{{ $json.requirement }}"

Proyecto: {{ $json.project }}
Prioridad: {{ $json.priority || "media" }}

Formato (JSON array):
[
  {
    "titulo": "<título corto en imperativo>",
    "descripcion": "<qué hay que hacer y por qué>",
    "criterios": ["criterio de aceptación 1", "criterio 2"],
    "estimacion": "<XS|S|M|XL>",
    "dependencias": ["ticket-XXX o null"]
  }
]

Máximo 5 tickets. Divide lo más posible.
```

### 4.51 — Sentiment Monitor (Redes Sociales)

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.2

```
Analiza el sentimiento de estos {{ $json.count || 10 }} posts que mencionan a {{ $json.brand }}:

{{ $json.posts }}

JSON puro (array de análisis individual + resumen):
{
  "posts": [
    {
      "texto_resumido": "<20 palabras>",
      "sentimiento": "<muy_positivo|positivo|neutral|negativo|muy_negativo>",
      "tema": "<tema principal>",
      "requiere_respuesta": <true|false>,
      "tipo": "<elogio|queja|pregunta|sugerencia|spam>"
    }
  ],
  "resumen": {
    "positivos": <n>,
    "neutrales": <n>,
    "negativos": <n>,
    "tema_mas_comun": "<tema>",
    "accion_recomendada": "<1 frase>"
  }
}
```

### 4.52 — Generador de OKRs / KPIs

**Nodo:** OpenAI Chat Model
**Temperatura:** 0.4

```
Genera 3 OKRs para este objetivo de negocio:

Objetivo: {{ $json.objective }}
Industria/Tipo: {{ $json.industry }}
Período: {{ $json.period || "Q3 2026" }}
Equipo: {{ $json.team || "individual" }}

Para cada OKR:
{
  "O": "<Objective — inspirador, cualitativo>",
  "KR": [
    "KR1: [métrica] desde [baseline] a [target]",
    "KR2: [métrica] desde [baseline] a [target]",
    "KR3: [métrica] desde [baseline] to[target]"
  ]
}

Los KRs deben ser específicos y medibles. Objetivo ambicioso pero alcanzable.
```

---

## 📚 Plantillas extra (incluidas en templates/)

Además de los prompts de arriba, incluimos 4 workflows JSON listos para importar en n8n:

| Template | Qué hace |
|----------|----------|
| `ai-content-generator.json` | Genera contenido basado en trigger manual o schedule |
| `ai-email-responder.json` | Detecta nuevos emails y sugiere respuestas |
| `ai-data-extractor.json` | Extrae datos estructurados de texto libre |
| `ai-social-scheduler.json` | Programa y publica posts en redes sociales |

---

_Licencia MIT — Úsalos, modifícalos, véndelos como parte de tus propios proyectos._
_Creado por koi 🎏 | Koihub © 2026_
