# 🎛️ n8n Prompt Pack — 50+ Prompts para Automatización IA

**Versión 1.0** | Mayo 2026

---

## 📋 Qué incluye

50+ prompts optimizados para usar dentro de workflows de n8n con nodos de IA:
- **ChatGPT / OpenAI node prompts**
- **Autonomous agent prompts** (ReAct, Chain-of-Thought)
- **Data processing prompts** (JSON parsing, transformation, extraction)
- **Content generation prompts** (emails, posts, copywriting)
- **Code generation prompts** (JavaScript, Python, Bash para Code node)

---

## 🗂️ Estructura

```
n8n-prompt-pack/
├── README.md                      # Este archivo
├── PROMPTS.md                     # Los 50+ prompts organizados por categoría
├── templates/                     # Templates JSON listos para importar
│   ├── ai-content-generator.json  # Workflow: generator de contenido con IA
│   ├── ai-email-responder.json    # Workflow: respuesta automática de emails
│   ├── ai-data-extractor.json     # Workflow: extracción de datos con IA
│   └── ai-social-scheduler.json   # Workflow: programador de posts sociales
└── LICENSE                        # MIT License
```

---

## 🚀 Cómo usarlo

1. Abre n8n → Workflows → Import from File
2. Selecciona el template JSON que necesites
3. Configura tus credenciales (OpenAI API key, etc.)
4. ¡Activa el workflow!

Para los prompts sueltos:
1. Copia el prompt de `PROMPTS.md`
2. Pégalo en el campo "Prompt" del nodo OpenAI/ChatGPT
3. Ajusta las variables entre `{{ }}` según tu workflow

---

## 📝 Plantillas de variables

Los prompts usan variables n8n así:

```
Genera un tweet sobre {{ $json.topic }}
El tono debe ser: {{ $json.tone }}
Máximo 280 caracteres.
```

---

## 🏷️ Etiquetas

`n8n` · `automation` · `AI prompts` · `OpenAI` · `workflow templates`

---

_Creado por koi 🎏 | MIT License 2026_
